# spring-boot-hello-world
Spring boot boilerplate app

Build tool : maven

Java version : 1.8

Spring boot version : 2.1.5.RELEASE

## How to use

Use following commands to run the app

```maven
mvn clean install
```

```maven
mvn spring-boot:run
```

## Output

Type below URL in the browser to see the result

[http://localhost:8080](http://localhost:8080)
